package com.hiddenhistory.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Hidden History
 *
 * SettingsViewModel
 *
 * Responsible for application-level settings state.
 *
 * This ViewModel intentionally does not modify the existing
 * ProfileViewModel or profile functionality.
 *
 * Settings that require persistent storage can be connected
 * later without changing the SettingsScreen structure.
 */
class SettingsViewModel : ViewModel() {

    // ------------------------------------------------------------------------
    // Settings state
    // ------------------------------------------------------------------------

    private val _notificationsEnabled =
        MutableStateFlow(true)

    val notificationsEnabled: StateFlow<Boolean> =
        _notificationsEnabled.asStateFlow()


    private val _analysisWarningsEnabled =
        MutableStateFlow(true)

    val analysisWarningsEnabled: StateFlow<Boolean> =
        _analysisWarningsEnabled.asStateFlow()


    // ------------------------------------------------------------------------
    // Notification setting
    // ------------------------------------------------------------------------

    fun setNotificationsEnabled(
        enabled: Boolean
    ) {
        _notificationsEnabled.value = enabled
    }


    // ------------------------------------------------------------------------
    // Analysis warning setting
    // ------------------------------------------------------------------------

    fun setAnalysisWarningsEnabled(
        enabled: Boolean
    ) {
        _analysisWarningsEnabled.value = enabled
    }
}